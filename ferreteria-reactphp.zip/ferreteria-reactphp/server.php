<?php

require 'vendor/autoload.php';

use React\Http\HttpServer;
use React\Http\Message\Response;
use React\Socket\SocketServer;
use Psr\Http\Message\ServerRequestInterface;
use React\EventLoop\Loop;
use React\MySQL\Factory as MySQLFactory;

$loop = Loop::get();

// Reemplaza con tus credenciales reales de MySQL
$mysqlFactory = new MySQLFactory($loop);
$db = $mysqlFactory->createLazyConnection('root@127.0.0.1/ferreteria');

$server = new HttpServer(function (ServerRequestInterface $request) use ($db) {
    $path = $request->getUri()->getPath();
    $method = $request->getMethod();

    switch ($path) {
        case '/index.html':
            $html = @file_get_contents('public/index.html');
            return new Response(200, ['Content-Type' => 'text/html'], $html ?: 'Error al cargar inicio');

        case '/contact.html':
            $html = @file_get_contents('public/contact.html');
            return new Response(200, ['Content-Type' => 'text/html'], $html ?: 'Error al cargar contacto');

        case '/add.html':
            $html = @file_get_contents('public/add.html');
            return new Response(200, ['Content-Type' => 'text/html'], $html ?: 'Error al cargar formulario');

        case '/producto.php':
            ob_start();
            include 'public/producto.php';
            $html = ob_get_clean();
            return new Response(200, ['Content-Type' => 'text/html'], $html ?: 'Error al cargar productos');

        case '/style.css':
            $css = @file_get_contents('public/style.css');
            return new Response(200, ['Content-Type' => 'text/css'], $css ?: '');

        case '/data':
            if ($method === 'GET') {
                return $db->query('SELECT * FROM productos')->then(
                    fn($result) => new Response(200, ['Content-Type' => 'application/json'], json_encode($result->resultRows)),
                    fn() => new Response(500, [], 'Error al obtener productos')
                );
            }

            $params = json_decode((string) $request->getBody(), true);
            if (!$params) {
                return new Response(400, [], 'Datos no válidos');
            }

            if ($method === 'POST') {
                return $db->query(
                    'INSERT INTO productos (nombre, precio, descripcion) VALUES (?, ?, ?)',
                    [$params['nombre'], $params['precio'], $params['descripcion']]
                )->then(
                    fn() => new Response(201, [], 'Producto creado'),
                    fn() => new Response(500, [], 'Error al crear producto')
                );
            }

            if ($method === 'PUT') {
                return $db->query(
                    'UPDATE productos SET nombre = ?, precio = ?, descripcion = ? WHERE id = ?',
                    [$params['nombre'], $params['precio'], $params['descripcion'], $params['id']]
                )->then(
                    fn() => new Response(200, [], 'Producto actualizado'),
                    fn() => new Response(500, [], 'Error al actualizar')
                );
            }

            if ($method === 'DELETE') {
                return $db->query(
                    'DELETE FROM productos WHERE id = ?',
                    [$params['id']]
                )->then(
                    fn() => new Response(200, [], 'Producto eliminado'),
                    fn() => new Response(500, [], 'Error al eliminar')
                );
            }

            return new Response(405, [], 'Método no permitido');

        case '/data/productos.json':
            return $db->query('SELECT * FROM productos')->then(
                fn($result) => new Response(200, ['Content-Type' => 'application/json'], json_encode($result->resultRows)),
                fn() => new Response(500, [], 'Error al obtener productos')
            );

        default:
            return new Response(404, [], 'Ruta no encontrada');
    }
});

$socket = new SocketServer('0.0.0.0:8080', [], $loop);
$server->listen($socket);
echo "Servidor corriendo en http://localhost:8080/index.html\n";
$loop->run();