CREATE DATABASE ferreteria;
USE ferreteria;

CREATE TABLE productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    precio DECIMAL(10,2),
    descripcion TEXT
);

CREATE TABLE contactos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    mensaje TEXT NOT NULL
);

INSERT INTO productos (nombre, precio, descripcion) VALUES
('Martillo de acero', 150.00, 'Martillo resistente con mango de goma antideslizante.'),
('Destornillador Philips', 45.50, 'Destornillador tipo cruz, punta magnética.'),
('Taladro inalámbrico', 1250.00, 'Taladro de 20V con batería recargable y maletín.'),
('Cinta métrica 5m', 30.00, 'Cinta de medición con freno automático, carcasa metálica.'),
('Llave inglesa ajustable', 80.00, 'Llave de acero forjado con apertura de hasta 30mm.'),
('Caja de tornillos surtidos', 60.00, 'Caja con 300 piezas de tornillos variados.'),
('Nivel de burbuja 40cm', 55.00, 'Nivel profesional con 3 burbujas para múltiples ángulos.'),
('Alicate universal', 70.00, 'Alicate con mango ergonómico y recubrimiento antideslizante.');