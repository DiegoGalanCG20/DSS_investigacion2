<?php

$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "ferreteria";
$port = 3306;

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
echo "Conexión exitosa";

// Insertar productos
$sql = "INSERT INTO productos (nombre, precio, descripcion) VALUES 
('Martillo de acero', 150.00, 'Martillo resistente con mango de goma antideslizante.'),
('Destornillador Philips', 45.50, 'Destornillador tipo cruz, punta magnética.'),
('Taladro inalámbrico', 1250.00, 'Taladro de 20V con batería recargable y maletín.'),
('Cinta métrica 5m', 30.00, 'Cinta de medición con freno automático, carcasa metálica.'),
('Llave inglesa ajustable', 80.00, 'Llave de acero forjado con apertura de hasta 30mm.'),
('Caja de tornillos surtidos', 60.00, 'Caja con 300 piezas de tornillos variados.'),
('Nivel de burbuja 40cm', 55.00, 'Nivel profesional con 3 burbujas para múltiples ángulos.'),
('Alicate universal', 70.00, 'Alicate con mango ergonómico y recubrimiento antideslizante.')";

if ($conn->query($sql) === TRUE) {
    echo "Productos insertados exitosamente";
} else {
    echo "Error al insertar productos: " . $conn->error;
}

// Obtener productos
$sql = "SELECT id, nombre, precio, descripcion FROM productos";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Mostrar datos de cada fila
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - Nombre: " . $row["nombre"]. " - Precio: " . $row["precio"]. " - Descripción: " . $row["descripcion"]. "<br>";
    }
} else {
    echo "0 resultados";
}

$conn->close();
?>